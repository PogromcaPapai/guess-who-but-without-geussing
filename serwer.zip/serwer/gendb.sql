-- SQLite
DROP TABLE cechy;

CREATE TABLE cechy (
    nazwa       varchar(30) not NULL,
    uwagi       varchar(600) not NULL,
    Alex        tinyint not NULL,
    Alfred      tinyint not NULL,
    Anita       tinyint not NULL,
    Anne        tinyint not NULL,
    Bernard     tinyint not NULL,
    Bill        tinyint not NULL,
    Charles     tinyint not NULL,
    Claire      tinyint not NULL,
    David       tinyint not NULL,
    Eric        tinyint not NULL,
    Frans       tinyint not NULL,
    George      tinyint not NULL,
    Herman      tinyint not NULL,
    Joe         tinyint not NULL,
    Maria       tinyint not NULL,
    Max         tinyint not NULL,
    Paul        tinyint not NULL,
    Peter       tinyint not NULL,
    Philip      tinyint not NULL,
    Richard     tinyint not NULL,
    Robert      tinyint not NULL,
    Sam         tinyint not NULL,
    Susan       tinyint not NULL,
    Tom         tinyint not NULL,
    id_cecha    INTEGER PRIMARY KEY
);